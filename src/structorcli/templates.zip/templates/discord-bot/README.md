# {{project_name}}

Discord bot starter project.

To run:

```bash
npm install
node bot.js
