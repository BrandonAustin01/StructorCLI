# {{project_name}}

Welcome to your Rust project scaffolded by CLI Scaffolder!

## Quick Start

```bash
cargo run
```

## Project Structure

- `main.rs`: Main Rust file
- `Cargo.toml`: Rust project config
- `README.md`: Documentation
