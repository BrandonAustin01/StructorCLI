fn main() {
    println!("Hello, Rust world!");
}
