# {{project_name}}

Welcome to your HTML project scaffolded by CLI Scaffolder!

## Quick Start

Open `index.html` in your browser.

## Project Structure

- `index.html`: Main HTML page
- `README.md`: Project documentation
