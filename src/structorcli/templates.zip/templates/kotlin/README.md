# {{project_name}}

Welcome to your Kotlin project scaffolded by CLI Scaffolder!

## Quick Start

```bash
kotlinc Main.kt -include-runtime -d app.jar
java -jar app.jar
```

## Project Structure

- `Main.kt`: Main Kotlin file
- `README.md`: Documentation
