<template>
  <div id="app">
    <h1>Hello from {{ project_name }}!</h1>
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
#app {
  text-align: center;
}
</style>
