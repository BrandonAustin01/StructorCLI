# {{project_name}}

Vue 3 starter project.

To run:

```bash
npm install
npm run serve
