# {{project_name}}

GraphQL Apollo starter project.

To run:

```bash
npm install
node server.js
