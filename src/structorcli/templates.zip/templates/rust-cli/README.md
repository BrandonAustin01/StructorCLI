# {{project_name}}

Simple Rust CLI starter.

To run:

```bash
cargo run
