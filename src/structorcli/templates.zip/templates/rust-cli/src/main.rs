fn main() {
    println!("Hello from {{project_name}}!");
}