// main.cpp
#include <iostream>

int main()
{
    std::cout << "Hello, C++ World!" << std::endl;
    return 0;
}
