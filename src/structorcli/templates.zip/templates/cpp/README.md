# {{project_name}}

Welcome to your C++ project scaffolded by CLI Scaffolder!

## Quick Start

```bash
g++ main.cpp -o app
./app
```

## Project Structure

- `main.cpp`: Main C++ source file
- `README.md`: Project documentation
