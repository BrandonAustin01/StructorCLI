<script>
  let name = "{{project_name}}";
</script>

<main>
  <h1>Hello from {name}!</h1>
</main>

<style>
  main {
    text-align: center;
    padding: 1em;
  }
</style>
