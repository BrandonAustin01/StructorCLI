# {{project_name}}

Svelte starter project.

To run:

```bash
npm install
npm run dev
