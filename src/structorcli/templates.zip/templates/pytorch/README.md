# {{project_name}}

Simple PyTorch starter project.

To run:

```bash
pip install -r requirements.txt
python main.py
