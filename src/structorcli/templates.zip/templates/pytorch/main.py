import torch

def main():
    print("Hello from {{project_name}} using PyTorch!")

if __name__ == "__main__":
    main()
