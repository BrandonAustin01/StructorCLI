# {{project_name}}

Django starter project.

Initialize with:

```bash
django-admin startproject {{project_name}} .
python manage.py runserver
