# {{project_name}}

Welcome to your C# project scaffolded by CLI Scaffolder!

## Quick Start

```bash
dotnet new console -n {{project_name}}
dotnet run
```

## Project Structure

- `Program.cs`: Main program
- `README.md`: Documentation
