# {{project_name}}

This is a FastAPI starter project.
Run with:

```bash
uvicorn main:app --reload
