# {{project_name}}

Simple React starter project.

To run:

```bash
npm install
npm start
