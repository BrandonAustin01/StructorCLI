# {{project_name}}

Welcome to your Swift project scaffolded by CLI Scaffolder!

## Quick Start

```bash
swift main.swift
```

## Project Structure

- `main.swift`: Main Swift file
- `README.md`: Documentation
