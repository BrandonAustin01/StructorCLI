# {{project_name}}

Welcome to your Bash project scaffolded by CLI Scaffolder!

## Quick Start

```bash
chmod +x script.sh
./script.sh
```

## Project Structure

- `script.sh`: Main Bash script
- `README.md`: Documentation
