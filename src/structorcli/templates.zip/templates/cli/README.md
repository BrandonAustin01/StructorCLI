# {{project_name}}

Welcome to your CLI project scaffolded by CLI Scaffolder!

## Quick Start

```bash
pip install -r requirements.txt
python cli.py
```

## Project Structure

- `cli.py`: CLI entry script
- `requirements.txt`: CLI dependencies
- `README.md`: Project documentation
