# {{project_name}}

Simple Go HTTP server starter.

To run:

```bash
go run main.go
