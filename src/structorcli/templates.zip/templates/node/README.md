# {{project_name}}

Welcome to your Node.js project scaffolded by CLI Scaffolder!

## Quick Start

```bash
npm install
node app.js
```

## Project Structure

- `app.js`: Main Node.js app
- `package.json`: Node dependencies
- `README.md`: Documentation
