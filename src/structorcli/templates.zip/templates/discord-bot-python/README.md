# {{project_name}}

Simple Python Discord bot starter project.

## Setup

```bash
pip install -r requirements.txt
python bot.py
