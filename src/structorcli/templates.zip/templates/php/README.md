# {{project_name}}

Welcome to your PHP project scaffolded by CLI Scaffolder!

## Quick Start

Open `index.php` in a web server (e.g., localhost).

## Project Structure

- `index.php`: Main PHP file
- `README.md`: Documentation
