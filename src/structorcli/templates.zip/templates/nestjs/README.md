# {{project_name}}

NestJS starter project.

To run:

```bash
npm install
npm run start
