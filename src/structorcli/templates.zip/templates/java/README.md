# {{project_name}}

Welcome to your Java project scaffolded by CLI Scaffolder!

## Quick Start

```bash
javac Main.java
java Main
```

## Project Structure

- `Main.java`: Main Java source file
- `README.md`: Documentation
