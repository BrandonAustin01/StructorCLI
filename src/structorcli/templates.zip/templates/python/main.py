# main.py
def main():
    print("Hello, Python World!")

if __name__ == "__main__":
    main()
