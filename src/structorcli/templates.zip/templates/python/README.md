# {{project_name}}

Welcome to your Python project scaffolded by CLI Scaffolder!

## Quick Start

```bash
python main.py
```

## Project Structure

- `main.py`: Main Python script
- `README.md`: Documentation
