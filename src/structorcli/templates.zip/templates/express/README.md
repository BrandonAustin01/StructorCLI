# {{project_name}}

Express.js starter project.

To run:

```bash
npm install
node app.js
