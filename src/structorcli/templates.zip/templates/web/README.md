# {{project_name}}

Welcome to your Web project scaffolded by CLI Scaffolder!

## Quick Start

Open `index.html` in your browser.

## Project Structure

- `index.html`: Main web page
- `style.css`: Stylesheet
- `script.js`: JavaScript file
- `README.md`: Documentation
