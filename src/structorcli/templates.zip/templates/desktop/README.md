# {{project_name}}

Welcome to your Desktop App project scaffolded by CLI Scaffolder!

## Quick Start

```bash
pip install -r requirements.txt
python app.py
```

## Project Structure

- `app.py`: Desktop app entry point
- `requirements.txt`: App dependencies
- `README.md`: Documentation
