# {{project_name}}

Welcome to your Go project scaffolded by CLI Scaffolder!

## Quick Start

```bash
go run main.go
```

## Project Structure

- `main.go`: Main Go source file
- `go.mod`: Module file
- `README.md`: Documentation
